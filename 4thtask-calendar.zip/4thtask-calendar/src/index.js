import BookingCalendar from './BookingCalendar';

module.exports = BookingCalendar;
