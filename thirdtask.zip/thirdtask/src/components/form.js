import React, { Component } from 'react';

const Form = React.createClass({

    getInitialState() {
        return {
            fname: this.props.bofnamedy || '',
            lname: this.props.lname || '',
            email: this.props.lname || '',
            jobtitle:this.props.jobtitle || '',
            exp:this.props.exp || '',
        }
    },

    componentWillReceiveProps(props) {
        this.setState(props);
    },

    handlebirthdateChange(e) {
        this.setState({
            birthdate: e.target.value
        });
    },

    handlefnameChange(e) {
        this.setState({
            title: e.target.value
        });
    },

    handleSubmit(e) {
        e.preventDefault();
        this.props.onSubmit(this.state);
    },

    render() {
        return (
            <form name="blog_post" className="form-horizontal" onSubmit={this.handleSubmit}>
                <div id="blog_post">
                    <div className="form-group">
                        <label className="col-sm-2 control-label required" htmlFor="blog_post_fname">First Name</label>
                        <div className="col-sm-10">
                            <input type="text"
                                   id="blog_post_fname"
                                   required="required"
                                   value={this.state.fname}
                                   onChange={this.handlefnameChange}
                                   className="form-control"/>
                        </div>
                    </div>


                    <div className="form-group">
                        <label className="col-sm-2 control-label required" htmlFor="blog_post_lname">Last Name</label>
                        <div className="col-sm-10">
                            <input type="text"
                                   id="blog_post_lname"
                                   required="required"
                                   value={this.state.lname}
                                   className="form-control"/>
                        </div>
                    </div>


                    <div className="form-group">
                        <label className="col-sm-2 control-label required" htmlFor="blog_post_email">Email</label>
                        <div className="col-sm-10">
                            <input type="text"
                                   id="blog_post_email"
                                   required="required"
                                   value={this.state.email}
                                   className="form-control"/>
                        </div>
                    </div>



                    <div className="form-group">
                        <label className="col-sm-2 control-label required" htmlFor="blog_post_birthdate">Birthdate</label>
                        <div className="col-sm-10">
                            <input type="text"
                                   id="blog_post_birthdate"

                                   value={this.state.birthdate}
                                   onChange={this.handlebirthdateChange}
                                   className="form-control"/>
                        </div>
                    </div>



                    <div className="form-group">
                        <label className="col-sm-2 control-label required" htmlFor="blog_post_jobtitle">Job Title</label>
                        <div className="col-sm-10">
                            <input type="text"
                                   id="blog_post_jobtitle"
                                   required="required"
                                   value={this.state.jobtitle}
                                   className="form-control"/>
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="col-sm-2 control-label required" htmlFor="blog_post_jobtitle">No. of years Experience</label>
                        <div className="col-sm-10">
                            <input type="text"
                                   id="blog_post_exp"
                                   required="required"
                                   value={this.state.exp}
                                   className="form-control"/>
                        </div>
                    </div>



                    <div className="form-group">
                        <div className="col-sm-2"></div>
                        <div className="col-sm-10">
                            <button type="submit"
                                    id="blog_post_submit"
                                    className="btn-default btn">
                                Submit
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        );
    }
});

export default Form;
