import React, { Component } from 'react';

const NotFoundPage = () => {
    return (
        <h1>Nothing to see here, move along, move along...</h1>
    );
};

export default NotFoundPage;
