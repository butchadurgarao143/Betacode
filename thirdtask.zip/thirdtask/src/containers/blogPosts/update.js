import React, { Component } from 'react';
import Form from '../../components/form';
import { fetchBlogPost, updateBlogPost } from '../../actions/blogPostActions';

const Update = React.createClass ({

    getInitialState() {
        return {
            blogPost: {}
        };
    },

    componentDidMount() {
        fetchBlogPost(this.props.params.postId)
            .then((data) => {
                this.setState(state => {
                    state.blogPost = data;
                    return state;
                });
            })
            .catch((err) => {
                console.error('err', err);
            });
    },

    handleSubmit(data) {
        updateBlogPost(this.state.blogPost.id, data);
        this.props.router.push('/');
    },

    render() {
        return (
            <div>
                <Form onSubmit={this.handleSubmit.bind(this)}
                      fname={this.state.blogPost.fname}
                      lname={this.state.blogPost.lname}
                      email={this.state.blogPost.email}
                      birthdate={this.state.blogPost.birthdate}
                      jobtitle={this.state.blogPost.jobtitle}
                      exp={this.state.blogPost.exp}

                      ></Form>
            </div>
        );
    }
});

export default Update;
